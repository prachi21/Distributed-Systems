/*
 * Prachi Gokhale
 * Person Number: 5009-6829
 * PA4
 */

package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.TreeMap;
import java.util.Map.Entry;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import java.util.HashMap;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {
	SimpleDynamoDBHelper mOpenHelper;
	SQLiteDatabase db;
	static String myPort;
	static final int SERVER_PORT = 10000;
    
	public static final String ldump="@";
	public static final String gdump="*";
	//messages to send
	
	static final String key_val_msg="key_val";
	static final String query_msg = "query";
	static final String query_success_msg = "query_succ";
	static final String delete_msg = "delete";
	static final String rejoin = "join";
	static final String rejoin_ack="rejoin_ack";
	static final String gdump_ack="gdump_ack";
	
	//variables for has values of ports:
	static boolean flag =true;
	static boolean SingleQryflag =true;
	boolean delete_flag=false;
	static MatrixCursor gcursor;
	static int val_sent=0;
	static int val_received=0;
	static int count=0;
	
	//public ArrayList<String> successors;
	static public String successor1="";
	static public String successor2 ="";
	static public String successor3="";
	static public String successor4="";
	static public String predecessor1="";
	static public String predecessor2="";
	
	static public String k1,k2,k3,k4,k5 = null;
	static public ArrayList<String> space_id= new ArrayList<String>();
	static public HashMap<String,String> corpus = new HashMap<String, String>();
	static public HashMap<String,String> singleKeydb = new HashMap<String, String>();
	static public HashMap<String,String> gdump_corpus = new HashMap<String, String>();
	static public TreeMap<String,String> space = new TreeMap<String, String>();
    
	static final String TAG =SimpleDynamoProvider.class.getSimpleName();
	Uri providerUri = Uri.parse("content://edu.buffalo.cse.cse486586.simpledynamo.provider");
	
	Lock lock = new Lock();
	public Object lockOnInsert = new Object();
    
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		db.delete("SimpleDynamo", null, null);
		
		successor1=getSuccessors(myPort);
		successor2=getSuccessors(successor1);
		successor3=getSuccessors(successor2);
		successor4=getSuccessors(successor3);
			
	
		new Thread(new clientTask(myPort,delete_msg,successor1,myPort,"%","%","%","%")).start();
		new Thread(new clientTask(myPort,delete_msg,successor2,myPort,"%","%","%","%")).start();
		new Thread(new clientTask(myPort,delete_msg,successor3,myPort,"%","%","%","%")).start();
		new Thread(new clientTask(myPort,delete_msg,successor4,myPort,"%","%","%","%")).start();
		
		
		return 0;
	}
    
    
	@Override
	public Uri insert(Uri uri, ContentValues values) {
		synchronized (lockOnInsert) {
            // TODO Auto-generated method stub
            String content_key=values.getAsString("key");
            String content_value=values.getAsString("value");
            //initialise the variables
            String key_hash=null;
            String add_here="";
            
            try {
                key_hash = genHash(content_key);
                if(space.higherEntry(key_hash) == null)
                {
                    String key1 = space.firstKey();
                    add_here = space.get(key1);
                    successor1=getSuccessors(add_here);
                    successor2=getSuccessors(successor1);
                    Log.v("Inside insert method", "add_here:"+add_here+"successor1:"+successor1+"successor2"+successor2);
                    new Thread(new clientTask(myPort,key_val_msg,add_here,content_key,content_value,"insert","%","%")).start();
                    new Thread(new clientTask(myPort,key_val_msg,successor1,content_key,content_value,"insert","%","%")).start();
                    new Thread(new clientTask(myPort,key_val_msg,successor2,content_key,content_value,"insert","%","%")).start();
                    
                }
                else
                {
                    
                    add_here = space.higherEntry(key_hash).getValue();
                    Log.v("add_here value", add_here);
                    //  successors = getSuccessors(add_here)
                    successor1=getSuccessors(add_here);
                    successor2=getSuccessors(successor1);
                    Log.v(" if block Inside insert method", "add_here:"+add_here+"successor1:"+successor1+"successor2"+successor2);
                    new Thread(new clientTask(myPort,key_val_msg,add_here,content_key,content_value,"insert","%","%")).start();
                    new Thread(new clientTask(myPort,key_val_msg,successor1,content_key,content_value,"insert","%","%")).start();
                    new Thread(new clientTask(myPort,key_val_msg,successor2,content_key,content_value,"insert","%","%")).start();
                }
                
            }catch (NoSuchAlgorithmException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
		}
        
		return uri;
	}
    
	public String getSuccessors(String avd)
	{
		if(avd.equalsIgnoreCase("11124"))
		{
			return "11112";
		}
		if(avd.equalsIgnoreCase("11112"))
		{
			return "11108";
		}
		if(avd.equalsIgnoreCase("11108"))
		{
			return "11116";
		}
		if(avd.equalsIgnoreCase("11116"))
		{
			return "11120";
		}
		else if(avd.equalsIgnoreCase("11120"))
		{
			return "11124";
		}
		return null;
	}
	
	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getPrecedessor(String avd)
	{
		if(avd.equalsIgnoreCase("11124"))
		{
			return "11120";
		}
		if(avd.equalsIgnoreCase("11112"))
		{
			return "11124";
		}
		if(avd.equalsIgnoreCase("11108"))
		{
			return "11112";
		}
		if(avd.equalsIgnoreCase("11116"))
		{
			return "11108";
		}
		else if(avd.equalsIgnoreCase("11120"))
		{
			return "11116";
		}
		return null;
	}

    
	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		mOpenHelper = new SimpleDynamoDBHelper(getContext());
		db=mOpenHelper.getWritableDatabase();
        
		//get key space
		try {
			k1 = genHash("5554");
			k2 = genHash("5556");
			k3 = genHash("5558");
			k4 = genHash("5560");
			k5 = genHash("5562");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		space.put(k1, "11108");
		space.put(k2, "11112");
		space.put(k3, "11116");
		space.put(k4, "11120");
		space.put(k5, "11124");
		//space_id array will contain 11124, 1112, 11108, 11116, 11120
        
		for (String key : space.keySet()) {
			space_id.add(space.get(key));
		}
        
		//getting port number of AVD
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = String.valueOf((Integer.parseInt(portStr) * 2));
		
		//calling server task
		try{
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
            
		} catch (IOException e) {
			Log.e(TAG, "Can't create a ServerSocket");
            
		}
		
		
		gdump_corpus.clear();
		
		db.delete("SimpleDynamo", null, null);
		
		//sending message for joining again:
				successor1 = getSuccessors(myPort);
				predecessor1=getPrecedessor(myPort);
				predecessor2=getPrecedessor(predecessor1);
			
				//fromPort, msgType=rejoin, toPort, initiator...
				new Thread(new clientTask(myPort,rejoin,successor1,myPort,"%","%","%")).start();
				new Thread(new clientTask(myPort,rejoin,predecessor1,myPort,"%","%","%")).start();
				new Thread(new clientTask(myPort,rejoin,predecessor2,myPort,"%","%","%")).start();
     
		return false;
	}
    
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
        
		String[] result = {"key","value"};
		Cursor cursor;
	
        
		if(selection.equalsIgnoreCase(ldump))
		{
			cursor = db.rawQuery("select * from SimpleDynamo", null);
			return cursor;
		}
        
		if(selection.equalsIgnoreCase(gdump))
		{
			
			Cursor cursor1 = db.rawQuery("select * from SimpleDynamo", null);
			//cursor1.moveToFirst();
				//while (cursor1.isAfterLast() == false)
			while (cursor1.moveToNext())
				{
				String key = cursor1.getString(cursor1.getColumnIndex("key"));
				String value= cursor1.getString(cursor1.getColumnIndex("value"));
				gdump_corpus.put(key, value);
				//cursor1.moveToNext();
			    }
				
				successor1=getSuccessors(myPort);
				successor2=getSuccessors(successor1);
				successor3=getSuccessors(successor2);
				successor4=getSuccessors(successor3);
					
				new Thread(new clientTask(myPort,gdump,successor1,myPort,"%","%","%","%")).start();
				new Thread(new clientTask(myPort,gdump,successor2,myPort,"%","%","%","%")).start();
				new Thread(new clientTask(myPort,gdump,successor3,myPort,"%","%","%","%")).start();
				new Thread(new clientTask(myPort,gdump,successor4,myPort,"%","%","%","%")).start();
				
				while(flag)
					{
					
					}
	            
				MatrixCursor mcursor = new MatrixCursor(result);
				MatrixCursor dcursor = new MatrixCursor(result);
				for(Entry<String, String> entry : gdump_corpus.entrySet()) {
					mcursor.addRow(new Object[] {entry.getKey(), entry.getValue() });
					//dcursor.addRow(new Object[] {entry.getKey(), entry.getValue() });  //making copy of cursor
				}
				
				gdump_corpus.clear();
				return mcursor;
	
		
            
        }
		
		
        
		if(!selection.equalsIgnoreCase(gdump) && !selection.equalsIgnoreCase(ldump))
		{
			synchronized (this) {
                
                try {
                    String key_hash1= genHash(selection) ;
                    String real_avd="";
                    if(space.higherEntry(key_hash1) == null)
                    {
                        String key1 = space.firstKey();
                        real_avd = space.get(key1);
                        successor1= getSuccessors(real_avd);
                        successor2= getSuccessors(successor1);
                        //sending message to real_avd where initiator is myPort
                        new Thread(new clientTask(myPort,query_msg,real_avd,selection,myPort,"%","%","%")).start();
                        new Thread(new clientTask(myPort,query_msg,successor1,selection,myPort,"%","%","%")).start();
                        new Thread(new clientTask(myPort,query_msg,successor2,selection,myPort,"%","%","%")).start();
                        
                    }
                    else
                    {
                        real_avd = space.higherEntry(key_hash1).getValue();
                        successor1= getSuccessors(real_avd);
                        successor2= getSuccessors(successor1);
                        Log.v("add_here value", real_avd);
                        //  successors = getSuccessors(add_here)
                        new Thread(new clientTask(myPort,query_msg,real_avd,selection,myPort,"%","%","%")).start();
                        new Thread(new clientTask(myPort,query_msg,successor1,selection,myPort,"%","%","%")).start();
                        new Thread(new clientTask(myPort,query_msg,successor2,selection,myPort,"%","%","%")).start();
                        
                    }
                    
                    while(!(singleKeydb.containsKey(selection)))
                    {
                        
                    }
                   // SingleQryflag=true;
                    MatrixCursor mcursor = new MatrixCursor(result);
                    mcursor.addRow(new Object[] {selection,singleKeydb.get(selection) });
                    singleKeydb.clear();
                    return mcursor;
                }catch (NoSuchAlgorithmException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                
			}
		}
		
		return null;
	}
    
	@Override
	public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}
	

    
	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}
    
    
	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {
        
		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];
			ObjectInputStream in = null;
			try {
				while(true)
				{
					try {
						in = new ObjectInputStream(serverSocket.accept().getInputStream());
						Message m;
						m = (Message)in.readObject();
						Log.e("Inside server taskof "+ myPort, m.msgType+"  "+m.filename);
                        
						String toPort="";
						String msgType = "";
						String filename="";
						String content = "";
						
						String insert=null;
                        
						//contains 0= myPort, 1= msgType, 2=toPort,3 =filename, 4= content, 5=pred, 6=succ
						String received []= {m.myPort,m.msgType,m.toPort,m.filename,m.content,m.s1,m.s2};
						// String [] received = s.split(" ");
						
						msgType=received[1];
						toPort = received[2];
						filename = received[3];
						content = received[4];
						insert = received[5];
                        
						Log.e("In server taskof ==== "+toPort, m.msgType+" "+m.toPort +m.filename);
                        
						if(msgType.equalsIgnoreCase(key_val_msg))
						{
							try {
								lock.writeLock();
                                ContentValues kv = new ContentValues();
                                kv.put("key",filename.trim());
                                kv.put("value",content.trim());
                                
                                Log.v("Before Insert", filename );
                                Log.v("Before Insert", content );
                                
								
                                
                                if(insert.equalsIgnoreCase("insert"))
                                {
                                    db.insertWithOnConflict("SimpleDynamo", null,kv, SQLiteDatabase.CONFLICT_REPLACE);
                                    
                                    Log.v("After Insert", filename );
                                    Log.v("After Insert", content );
                                }
                                else
                                {  
                                    insert(providerUri, kv);   
                                }
                                
                                lock.release_writeLock();
                                
                            }catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
						}
 
						if(msgType.equalsIgnoreCase(gdump))
						{
							
							Cursor cursor = getContext().getContentResolver().query(providerUri, null, ldump, null, null);
							//cursor.moveToFirst();
							//while (cursor.isAfterLast() == false) 
							while(cursor.moveToNext())
							{   
								gdump_corpus.put(cursor.getString(cursor.getColumnIndex("key")), cursor.getString(cursor.getColumnIndex("value"))) ;
								//cursor.moveToNext();
							}
							
							new Thread(new clientTask(myPort,gdump_ack,m.filename,m.filename,"%","%","%","%")).start();				
					
						}
						
						if(msgType.equalsIgnoreCase(gdump_ack))
						{
							
							for(Entry<String, String> entry : m.gdump_hash.entrySet()) {
								gdump_corpus.put(entry.getKey(), entry.getValue());
							}
							count++;
							if(count==3) 		//wait for getting 3 reply
							{
								flag=false;
								count=0;
								
							}
                               
						}
						
						if(msgType.equalsIgnoreCase(query_msg))
						{
							try {
								lock.readLock();
                                String[] result1 = {"key","value"};
                                Cursor cursor = db.query("SimpleDynamo",result1,"key = "+"'"+m.filename+"'", null, null, null, null);
                                //MatrixCursor gcursor = new MatrixCursor(result1);
                                while(cursor.moveToNext()){
                                    int k1 =cursor.getColumnIndex("key");
                                    int v1 = cursor.getColumnIndex("value");
                                    String key_found = cursor.getString(k1);
                                    String value_found = cursor.getString(v1);
                                    if(key_found.equals(m.filename)){
                                        //message to convey that query result is found (sent to initiator)
                                        new Thread(new clientTask(myPort,query_success_msg,m.content,key_found,value_found,"%","%","%")).start();
                                        
                                        lock.release_readLock();
                                        break;
                                    }
                                    
                                }
							}catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
                                
                                
							}
							
							
						}
						if(msgType.equalsIgnoreCase(query_success_msg))
						{
							synchronized (this) {
								//count++;
                               // gcursor = new MatrixCursor(new String[] { "key", "value" });
                              //  gcursor.addRow(new String [] {received[3], received[4]});
                               // SingleQryflag=false;
								singleKeydb.put(received[3], received[4]);
                             //   if(count==3)
                               // {
                                //	count=0;
                                	//singleKeydb.put(received[3], received[4]);
                                	//SingleQryflag=false;
                                //}
							}
						}
						
						if(msgType.equalsIgnoreCase(rejoin))// & !m.filename.equalsIgnoreCase(myPort))
						{
							
							//getting data from local database
							Cursor cursor = getContext().getContentResolver().query(providerUri, null, ldump, null, null);
							//cursor.moveToFirst();
							//while (cursor.isAfterLast() == false) 
							while(cursor.moveToNext())
							{   
								corpus.put(cursor.getString(cursor.getColumnIndex("key")), cursor.getString(cursor.getColumnIndex("value"))) ;
								//cursor.moveToNext();
							}
							
							new Thread(new clientTask(myPort,rejoin_ack,m.filename,m.filename,"%","%","%","%")).start();
							
						}
						
						if(msgType.equalsIgnoreCase(rejoin_ack))
						{
							//find out the position of key, if it belongs to current avd, and 2 predecessors
							for (Entry<String, String> entry : m.gdump_hash.entrySet())
							{
								String pred1="";
								String pred2="";
								String this_avd="";
								String key1_hash;
								try {
									key1_hash = genHash(entry.getKey());
								
								if(space.higherEntry(key1_hash)==null)
								{
									String s = space.firstKey();
								    this_avd = space.get(s);		    
								}
								else
								{
									this_avd = space.higherEntry(key1_hash).getValue();
								}
								
								pred1=getPrecedessor(myPort);
								pred2=getPrecedessor(pred1);
								if(myPort.equalsIgnoreCase(this_avd) || this_avd.equalsIgnoreCase(pred1) || this_avd.equalsIgnoreCase(pred2))
								{
									ContentValues keyValueToInsert = new ContentValues();
									keyValueToInsert.put("key",entry.getKey());
									keyValueToInsert.put("value",entry.getValue());
									db.insertWithOnConflict("SimpleDynamo", null, keyValueToInsert, SQLiteDatabase.CONFLICT_REPLACE);
								}
										
									
								} catch (NoSuchAlgorithmException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
								
						if(msgType.equalsIgnoreCase(delete_msg))
						{
							//getContext().getContentResolver().delete(providerUri, m.filename, null);
							db.delete("SimpleDynamo", null, null);
						}
                        
					}catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return null;
            
		}
	}
    
	public class clientTask implements Runnable {
		//Message m;
		// String Port;
		String[] msg;
		clientTask(String... msgs)
		{
			this.msg=msgs;
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
            
			Message m= new Message(msg[0],msg[1],msg[2],msg[3],msg[4],msg[5],msg[6], new HashMap<String, String>());
			if(msg[1].equalsIgnoreCase(gdump))
			{
				m.gdump_hash=gdump_corpus;
				String Port=msg[2];
				ObjectOutputStream out=null;
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());
					out.writeObject(m);
					out.flush();
					out.close();
					socket0.close();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(msg[1].equalsIgnoreCase(gdump_ack))
			{
				m.gdump_hash=gdump_corpus;
				String Port=msg[2];
				ObjectOutputStream out=null;
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());
					out.writeObject(m);
					out.flush();
					out.close();
					socket0.close();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(msg[1].equalsIgnoreCase(query_msg))
			{
				String Port=msg[2];
				ObjectOutputStream out=null;
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());            
					out.writeObject(m);            
					out.flush();
					out.close();
					socket0.close();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			else if(msg[1].equalsIgnoreCase(query_success_msg))
			{
				String Port=msg[2]; 
				ObjectOutputStream out=null; 
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());            
					out.writeObject(m);            
					out.flush();
					out.close();
					socket0.close();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			else if(msg[1].equalsIgnoreCase(rejoin))
			{
				String Port=msg[2]; 
				ObjectOutputStream out=null; 
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());            
					out.writeObject(m);            
					out.flush();
					out.close();
					socket0.close();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			else if(msg[1].equalsIgnoreCase(rejoin_ack))
			{
				m.gdump_hash=corpus;    //sending Hashmap to recovered avd
				String Port=msg[2]; 
				ObjectOutputStream out=null; 
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());            
					out.writeObject(m);            
					out.flush();
					out.close();
					socket0.close();
					corpus.clear();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			else if(msg[1].equalsIgnoreCase(delete_msg))
			{
				
				String Port=msg[2]; 
				ObjectOutputStream out=null; 
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());            
					out.writeObject(m);            
					out.flush();
					out.close();
					socket0.close();
					corpus.clear();
				}catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}

			else{
                
				String Port=msg[2]; 
				ObjectOutputStream out=null; 
				Socket socket0;
				//String succ1 = getSuccessors(Port);
				//String succ2 = getSuccessors(succ1);
				//Log.v("successors", succ1+""+succ2);
				try {
					socket0 = new Socket("10.0.2.2",Integer.parseInt(Port));
					out = new ObjectOutputStream(socket0.getOutputStream());            
					out.writeObject(m);            
					out.flush();
					out.close();
					socket0.close();
                    
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
            
		}
        
	}	
    
}

class Message implements Serializable {
	//String msgToSend = myPort+":"+msgType+":"+"toPort"+":"+"filename"+":"+"content"+":"+"pred"+":"+"succ";
    
	public String myPort, toPort, msgType, filename,content, s1, s2 ;
	public HashMap<String,String> gdump_hash = new HashMap<String, String>();
    
	Message(){
        
	}
    
	Message(String myPort,String msgType, String toPort,String filename, String content, String predecessor, String successor, HashMap hashmap ){
		this.myPort=myPort;
		this.msgType = msgType;
		this.toPort = toPort;
		this.filename=filename;
		this.content=content;
		this.s1=predecessor;
		this.s2=successor;	
		this.gdump_hash.putAll(hashmap); 
	}
}

/*
    The below counting semaphore is being referred from internet source :
	 http://tutorials.jenkov.com/java-concurrency/read-write-locks.html
 */

 class Lock{
    
    int read_no      = 0;
    int writes       = 0;
    int writeRequests = 0;
    int lock_count=0;
	
	public synchronized void writeLock() throws InterruptedException{
		writeRequests++;
        
		while(0< writes || read_no > 0){
			wait();
		}
		writeRequests--;
		writes++;
	}
    
    
	public synchronized void readLock() throws InterruptedException{
		while(writes > 0 || 0 < writeRequests){
			wait();
		}
		read_no++;
	}
	
	public synchronized void release_writeLock() throws InterruptedException{
		writes--;
		notifyAll();
	}
    
	public synchronized void release_readLock(){
		read_no--;
		notifyAll();
	}
 }
    
	