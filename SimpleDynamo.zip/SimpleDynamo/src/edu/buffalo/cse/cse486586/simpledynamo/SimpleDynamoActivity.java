package edu.buffalo.cse.cse486586.simpledynamo;




import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SimpleDynamoActivity extends Activity {
	
	private ContentValues [] cv = null;
	private ContentResolver cr = null;
	public String TAG ="SimpleDynamoActivity";
	public String port = "5554";
	public Uri uri = Uri.parse("content://edu.buffalo.cse.cse486586.simpledynamo.provider");
    

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_simple_dht_main);
    
		TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
       
        findViewById(R.id.button3).setOnClickListener(
                new OnTestClickListener(tv, getContentResolver()));
        
        final Button ldump = (Button) findViewById(R.id.button1);
      		ldump.setOnClickListener(new View.OnClickListener() {
      			public void onClick(View v) {

      				TextView tv1 = (TextView) findViewById(R.id.textView1);
      			
      				Cursor resultCursor = getContentResolver().query(uri, null,"@", null, null);
      				while(resultCursor.moveToNext())
      				{				
      					tv1.append("**********************");
      					int key = resultCursor.getColumnIndex("key");
      					int value = resultCursor.getColumnIndex("value");

      					String returnKey = resultCursor.getString(key);
      					String returnValue = resultCursor.getString(value);

      					tv1.append("\t" + returnKey+"----"+returnValue + "\n");

      					
      				}
      				
      				//TextView tv1 = (TextView) findViewById(R.id.textView1);
                    //SimpleDynamoProvider sdp = new SimpleDynamoProvider();
                  /*  final int TEST_CNT = 1;
                    for (int i = 0; i < TEST_CNT; i++) 
                    {

                        Cursor resultCursor1 = getContentResolver().query(uri, null, "key" + Integer.toString(i), null, null);

                        while(resultCursor.moveToNext())
                        {                
                            tv1.append("^^^^^^^^^^^^");
                            int key = resultCursor1.getColumnIndex("key");
                            int value = resultCursor1.getColumnIndex("value");

                            String returnKey = resultCursor1.getString(key);
                            String returnValue = resultCursor1.getString(value);

                            tv1.append("\t" + returnKey+"--"+returnValue + "\n");                
                        }
      			} */
      			}
      		});
      		
      	 final Button gdump = (Button) findViewById(R.id.button2);
 			 gdump.setOnClickListener(new View.OnClickListener() {
 				public void onClick(View v) {

 					TextView tv1 = (TextView) findViewById(R.id.textView1);
 				
 					Cursor resultCursor = getContentResolver().query(uri, null,"*", null, null);
 					while(resultCursor.moveToNext())
 					{				
 						tv1.append("**********************");
 						int key = resultCursor.getColumnIndex("key");
 						int value = resultCursor.getColumnIndex("value");

 						String returnKey = resultCursor.getString(key);
 						String returnValue = resultCursor.getString(value);

 						tv1.append("\t" + returnKey+"----"+returnValue + "\n");

 						
 					}
 				}
 			});
 			
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_simple_dht_main, menu);
		return true;
	}

}
