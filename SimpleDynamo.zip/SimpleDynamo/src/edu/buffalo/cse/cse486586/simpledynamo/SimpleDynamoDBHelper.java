package edu.buffalo.cse.cse486586.simpledynamo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SimpleDynamoDBHelper extends SQLiteOpenHelper {
	// Defines the database name
    public static final String DBNAME = "MyDB";
    public static final String TABLENAME = "SimpleDynamo";
 // Holds the database object
   
    private static final String SQL_CREATE_MAIN = "CREATE TABLE IF NOT EXISTS " +
			TABLENAME +                       	// Table's name
		    "(" +                           	// The columns in the table
		    " key String PRIMARY KEY, " +
		    " value String"+ ")";

    SimpleDynamoDBHelper(Context context) {
        super(context, DBNAME, null, 1);
    }
	public void onCreate(SQLiteDatabase db) {

        // Creates the main table
        db.execSQL(SQL_CREATE_MAIN);
    }
	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

}
