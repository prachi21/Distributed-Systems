/* PA3 
submitted by:
Prachi Gokhale 
*/

package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDhtProvider extends ContentProvider{


	static final String REMOTE_PORT0 = "11108";
	static final String REMOTE_PORT1 = "11112";
	static final String REMOTE_PORT2 = "11116";
	static final String REMOTE_PORT3 = "11120";
	static final String REMOTE_PORT4 = "11124";
	static final int SERVER_PORT = 10000;

	//messages to send
	static final String join_msg="req";   //for join req
	static final String res_msg="res";
	static final String key_val_msg="key_val";

	SimpleDhtDBHelper mOpenHelper;
	SQLiteDatabase db;
	static String myPort;
	HashMap<String, String> global_database = new HashMap<String, String>();
	
	static final String query_msg = "query";
	static final String delete_msg = "delete";

	static int predecessor=0;
	static int successor=0;
	public static final String ldump="@";
	public static final String gdump="*";

	//variables for has values of ports:
	public static String myPort_hash = null;
	public static String predecessor_hash=null;
	public static String successor_hash=null;
	public static String key_hash=null;
	public static String emulator=null;
	public static String pre_emu=null;
	public static String succ_emu=null;
	static boolean flag =true;
	boolean delete_flag=false;
	
	static public HashMap<String,String> corpus = new HashMap<String, String>();

	static final String TAG =SimpleDhtProvider.class.getSimpleName();
	Uri providerUri = Uri.parse("content://edu.buffalo.cse.cse486586.simpledht.provider");

	private String getPortstr(String AVD) {
		String avd[] = {"5554","5556","5558","5560","5562"};

		if(AVD.equalsIgnoreCase(REMOTE_PORT0))
		{
			return avd[0];
		}
		if(AVD.equalsIgnoreCase(REMOTE_PORT1))
		{
			return avd[1];
		}
		if(AVD.equalsIgnoreCase(REMOTE_PORT2))
		{
			return avd[2];
		}
		if(AVD.equalsIgnoreCase(REMOTE_PORT3))
		{
			return avd[3];
		}
		if(AVD.equalsIgnoreCase(REMOTE_PORT4))
		{
			return avd[4];
		}
		return "";
	}


	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		
		 delete_flag=true;
	    	return 0;
	}


	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		String content_key=values.getAsString("key");
		String content_value=values.getAsString("value");
		//initialise the variables
		String key_hash=null; String myPort_hash=null; String pre_hash=null;String succ_hash=null;
		try {
			//getting hash values of all ports

			key_hash = genHash(content_key);
			myPort_hash = genHash(getPortstr(myPort));
			pre_hash = genHash(getPortstr(Integer.toString(predecessor)));
			succ_hash = genHash(getPortstr(Integer.toString(successor)));

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			//condition for base case
		if(myPort.equalsIgnoreCase(Integer.toString(predecessor)) ) 
			{
					db.insertWithOnConflict("SimpleDht", null, values, SQLiteDatabase.CONFLICT_REPLACE);
			}
		
		else {

			if(key_hash.compareTo(myPort_hash)>0)
			{
				if(succ_hash.compareTo(myPort_hash)<0)
				{
					new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,key_val_msg,Integer.toString(successor),content_key,content_value,"insert","%");
				}
				else
				{
					new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,key_val_msg,Integer.toString(successor),content_key,content_value,"%","%");
				}

			}
			else 
			{
				if(pre_hash.compareTo(key_hash)<0)
				{
					db.insertWithOnConflict("SimpleDht", null, values, SQLiteDatabase.CONFLICT_REPLACE);
				}
				else 
				{
					if(pre_hash.compareTo(myPort_hash)>0)
					{
						db.insertWithOnConflict("SimpleDht", null, values, SQLiteDatabase.CONFLICT_REPLACE);
					}
					else
					{
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,key_val_msg,Integer.toString(successor),content_key,content_value,"%","%");
					}
				}
			}
		}

		return uri;
		
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		mOpenHelper = new SimpleDhtDBHelper(getContext());	
		db=mOpenHelper.getWritableDatabase();

		//getting port number of AVD
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = String.valueOf((Integer.parseInt(portStr) * 2));

		//initializing predecessor and successor
		predecessor=Integer.parseInt(myPort);
		successor=Integer.parseInt(myPort);

		try {
			myPort_hash=genHash(getPortstr(myPort));
			predecessor_hash=genHash(getPortstr(Integer.toString(predecessor)));
			successor_hash=genHash(getPortstr(Integer.toString(successor)));
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if(!myPort.equals("11108"))
		{
			//sending fromPort, msgType, toPort, filename(copy of initiator), content,succ,next
			//ClientTask(myPort,"Req",REMOTE_PORT0,null,null, null, null);
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,join_msg,REMOTE_PORT0,myPort,"%","%","%");
		}
		
		//calling server task
				try{	
					ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
					new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

				} catch (IOException e) {
					Log.e(TAG, "Can't create a ServerSocket");

				}

		return false;
	}

	@Override
	public  Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
			String sortOrder) {
		// TODO Auto-generated method stub
		String[] result = {"key","value"};
		Cursor cursor;
		
		if(delete_flag)
        	return null;

		if(selection.equalsIgnoreCase(ldump))
		{
			cursor = db.rawQuery("select * from SimpleDht", null);
			return cursor;
		}
		
	   if(selection.equalsIgnoreCase(gdump))
		{
		 //base case
		 if(Integer.parseInt(myPort)==predecessor && Integer.parseInt(myPort)==successor)
		 {
			 cursor = db.rawQuery("select * from SimpleDht", null);
			 return cursor;
		 }
		 else
		 {
			 cursor = db.rawQuery("select * from SimpleDht", null);
			 cursor.moveToFirst();
			 while (cursor.isAfterLast() == false) {
				
				 String key = cursor.getString(cursor.getColumnIndex("key"));
				 String value= cursor.getString(cursor.getColumnIndex("value"));
				 corpus.put(key, value);
				 cursor.moveToNext();
			 }
			 new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,gdump,Integer.toString(successor),myPort,"%","%","%");
			 while(flag);

			 MatrixCursor mcursor = new MatrixCursor(result);
			 for(Entry<String, String> entry : corpus.entrySet()) {
				 mcursor.addRow(new Object[] {entry.getKey(), entry.getValue() });
			 }
			 return mcursor;
		 	}		
		}
	 
	 if(!selection.equalsIgnoreCase(gdump) && !selection.equalsIgnoreCase(ldump))
	 {
		 if(Integer.parseInt(myPort)==predecessor )   //&& Integer.parseInt(myPort)==successor)
		 {
			 cursor= db.query("SimpleDht",result,"key = "+"'"+selection+"'", null, null, null, null);
			 return cursor;
		 }
		 else
		 {
			 cursor = db.rawQuery("select * from SimpleDht", null);
			 cursor.moveToFirst();
			 while (cursor.isAfterLast() == false) {
				 
				 String key = cursor.getString(cursor.getColumnIndex("key"));
				 String value= cursor.getString(cursor.getColumnIndex("value"));
				 corpus.put(key, value);
				 cursor.moveToNext();
			 }
			 new ClientTask().doInBackground(myPort,gdump,Integer.toString(successor),myPort,"%","%","%");
			 while(flag);

			 MatrixCursor mcursor = new MatrixCursor(result);
			 if(corpus.containsKey(selection))
			 {
				 mcursor.addRow(new Object[]{selection, corpus.get(selection)});
			 }
			 return mcursor;
		 	
		 }

	 }

		

	 return null;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	//code taken from PA3 specification
	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}


	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {

			ServerSocket serverSocket = sockets[0];
			ObjectInputStream in = null;
			try {
				while(true)
				{
					in = new ObjectInputStream(serverSocket.accept().getInputStream());
					Message m;
					m = (Message)in.readObject();

					Log.e("Inside server taskof"+myPort, m.msgType+"  "+m.filename);
					
					String toPort="";
					String msgType = "";
					String fromPort = "";
					String filename="";
					String content = "";
					String pred = "";
					String succ = "";
					String initiator;
					String insert=null;

					//contains 0= myPort, 1= msgType, 2=toPort,3 =filename, 4= content, 5=pred, 6=succ
					String received []= {m.myPort,m.msgType,m.toPort,m.filename,m.content,m.predecessor,m.successor}; 
					// String [] received = s.split(" "); 	
					String from_port= received[0];
					msgType=received[1];
					toPort = received[2];
					filename = received[3];
					initiator=received[3];   //store copy of key: filename
					content = received[4];
					pred = received[5];
					insert = received[5];
					succ = received[6];

					//calculate the hash of node_join
					String from_port_hash=genHash(getPortstr(from_port));
					String initiator_hash=genHash(getPortstr(initiator));
					
					//String myPort_Hash=genHash(getPortstr(myPort));
					predecessor_hash=genHash(getPortstr(Integer.toString(predecessor)));
					successor_hash=genHash(getPortstr(Integer.toString(successor)));
					//myPort_Hash=genHash(getPortstr(myPort));
					
				
					//if msgType is key value pair then insert it in database
					if(msgType.equalsIgnoreCase(key_val_msg))
					{
						insert_in_db(filename, content, insert);
					}

					if(msgType.equalsIgnoreCase(res_msg))
					{
						response(pred, succ);
					}

					if(msgType.equalsIgnoreCase(join_msg))
					{
						join(from_port,initiator_hash,predecessor,successor,predecessor_hash,successor_hash, filename);
					}
					
					if(msgType.equalsIgnoreCase(gdump))
					{
						for(Entry<String, String> entry : m.gdump_hash.entrySet()) {
				               corpus.put(entry.getKey(), entry.getValue());
				     		 }
						
						if(m.filename.equalsIgnoreCase(myPort))
						{
							flag=false;
						}
						else
						{
						Cursor cursor = getContext().getContentResolver().query(providerUri, null, ldump, null, null);
						cursor.moveToFirst();
						while (cursor.isAfterLast() == false) {

					        corpus.put(cursor.getString(cursor.getColumnIndex("key")), cursor.getString(cursor.getColumnIndex("value"))) ;
							cursor.moveToNext();
					    }
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,gdump,Integer.toString(successor),m.filename,"%","%","%");
						}
					}
					
					if(msgType.equalsIgnoreCase(delete_msg))
					{
						getContext().getContentResolver().delete(providerUri, m.filename, null);
					}
				}

			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;

		}

		private void join(String from_port, String initiator_hash,int predecessor1, int successor1,
				String predecessor_hash, String successor_hash, String initiator) {
			//base case
			if(Integer.parseInt(myPort)==predecessor)
			{
				//Log.e(myPort, node_join);
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,initiator,initiator,"%",myPort,myPort);
				successor=Integer.parseInt(initiator.trim());
				predecessor=Integer.parseInt(initiator.trim());
				

			}
			else {
				
				if(initiator_hash.compareTo(myPort_hash)>0)
				{
					if(successor_hash.compareTo(myPort_hash)<0)
					{
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,Integer.toString(successor),initiator,"%",initiator,"%");
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,initiator,initiator,"%",myPort,Integer.toString(successor));
						successor=Integer.parseInt(initiator);
						Log.e(myPort,"    "+successor+"  "+predecessor);
					}
					else
					{
						//forward message to successor as it is
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,join_msg,Integer.toString(successor),initiator,"%","%","%");
					}

				}
				else 
				{
					if(predecessor_hash.compareTo(initiator_hash)<0)
					{
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,Integer.toString(predecessor),initiator,"%","%",initiator);
						new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,initiator,initiator,"%",Integer.toString(predecessor),myPort);
						predecessor=Integer.parseInt(initiator);
						Log.e(myPort,"    "+successor+"  "+predecessor);
					}
					else 
					{
						if(predecessor_hash.compareTo(myPort_hash)>0)
						{
							new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,Integer.toString(predecessor),initiator,"%","%",initiator);
							new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,res_msg,initiator,initiator,"%",Integer.toString(predecessor),myPort);
							predecessor=Integer.parseInt(initiator);
							Log.e(myPort,"    "+successor+"  "+predecessor);
						}
						else
						{
							new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort,join_msg,Integer.toString(successor),initiator,"%","%","%");
						}
					}
				}
			}
		}

		private void response(String pred, String succ) {
			// TODO Auto-generated method stub
			Log.e(myPort, "Response ...." +"Successor=="+succ +"  predecessor "+pred);

			if(!pred.equalsIgnoreCase("%"))
			{
				predecessor=Integer.parseInt(pred);

			} 

			if(!succ.equalsIgnoreCase("%"))
			{
				successor=Integer.parseInt(succ);
				
			}
			Log.e(myPort, "Response ...." +"Successor=="+succ +"  predecessor "+pred);
			
		}

		//helper methods for serverTask
		private void insert_in_db(String filename, String content, String insert) {
			// TODO Auto-generated method stub
			ContentValues kv = new ContentValues();
			kv.put("key",filename.trim());
			kv.put("value",content.trim());
			if(insert.equalsIgnoreCase("insert"))
			{
				db.insertWithOnConflict("SimpleDht", null,kv, SQLiteDatabase.CONFLICT_REPLACE);
			}
			else
			{
				   insert(providerUri, kv);
			}
		}
		protected void onProgressUpdate(String...strings) {
			return;
		}
	}

	private class ClientTask extends AsyncTask<String, Void, Void> {  
		protected Void doInBackground(String... msgs) {
			
			Message m = new Message();
			if(msgs[1].equalsIgnoreCase(gdump))
			{
				m.myPort=msgs[0];
				m.msgType=msgs[1];
				m.toPort=msgs[2];
				m.filename=msgs[3];
				m.content=msgs[4];
				m.predecessor=msgs[5];
				m.successor=msgs[6];
				m.gdump_hash=corpus;
			}
			else
			{
			m.myPort=msgs[0];
			m.msgType=msgs[1];
			m.toPort=msgs[2];
			m.filename=msgs[3];
			m.content=msgs[4];
			m.predecessor=msgs[5];
			m.successor=msgs[6];
			m.gdump_hash=new HashMap<String, String>();
			}
			String Port = msgs[2];
			ObjectOutputStream out=null; 
			
			try {
				Socket socket0 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),Integer.parseInt(Port));
				out = new ObjectOutputStream(socket0.getOutputStream());            
				out.writeObject(m);            
				out.flush();
				out.close();
				socket0.close();

			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null; 

		}

	}

}

class Message implements Serializable {
	//String msgToSend = myPort+":"+msgType+":"+"toPort"+":"+"filename"+":"+"content"+":"+"pred"+":"+"succ";

	public String myPort, toPort, msgType, filename,content, predecessor, successor ;
	public HashMap<String,String> gdump_hash = new HashMap<String, String>();

	Message(){

	}
	
	Message(String myPort,String msgType, String toPort,String filename, String content, String predecessor, String successor, HashMap hashmap ){
		this.myPort=myPort;
		this.msgType = msgType;
		this.toPort = toPort;
		this.filename=filename;
		this.content=content;
		this.predecessor=predecessor;
		this.successor=successor;	
		this.gdump_hash.putAll(hashmap); 
	}
}



