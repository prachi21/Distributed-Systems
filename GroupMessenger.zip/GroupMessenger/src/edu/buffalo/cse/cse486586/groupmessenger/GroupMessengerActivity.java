package edu.buffalo.cse.cse486586.groupmessenger;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Queue;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
	
	static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final int SERVER_PORT = 10000;
    static final String TAG =GroupMessengerActivity.class.getSimpleName();
    Uri providerUri = Uri.parse("content://edu.buffalo.cse.cse486586.groupmessenger.provider");
    String msg="";
    String myPort;
    int sequence = 0;
    int own_counter = 0;
    HashMap<Integer,String> receivedmap = new HashMap<Integer,String>();
    
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);
        
       
        //Getting a port number
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        final EditText editText = (EditText) findViewById(R.id.editText1);
        
        ContentValues keyValueToInsert = new ContentValues();
        // inserting <���key-to-insert���, ���value-to-insert���>
          keyValueToInsert.put("key", "key");
          keyValueToInsert.put("value","value");
        
           Uri newUri = getContentResolver().insert(
      		    providerUri,    		// assume we already created a Uri object with our provider URI
      		    keyValueToInsert
      		    );    
         //Query value from CP
   		Cursor resultCursor = getContentResolver().query(
   			    providerUri,    		// assume we already created a Uri object with our provider URI
   			    null,               	// no need to support the projection parameter
   			    "key",    				// we provide the key directly as the selection parameter
   			    null,                	// no need to support the selectionArgs parameter
   			    null                 	// no need to support the sortOrder parameter
   			);  

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
       
      
        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() 
        {
        	     public void onClick(View v) {
        		 msg = editText.getText().toString()+"\n";
        		 if(msg.length() > 128)
        		 {
        			 msg="Message is too long";
        		 }
        		 editText.setText(""); 		// This is one way to reset the input box.
                 TextView localTextView = (TextView) findViewById(R.id.textView1);
                 localTextView.append("\t" + msg); // This is one way to display a string.
                
             
                 //send realmsg, msgtype as "msg" hard-coded value  
                 new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, "msg");  
               
        	}
        	
        }
        );
        
        //creating a server task
   		try{
   			
        	ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
        	new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
         } catch (IOException e) {
        	 Log.e(TAG, "Can't create a ServerSocket");
             return;
        }
      
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        }
    
    
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            
              /*
             * TODO: Fill in your server code that receives messages and passes them
             * to onProgressUpdate().
             */
            
            try {
            	while(true)
            	{
            	Log.e("Inside server task", "server task");
              	BufferedReader br = new BufferedReader(new InputStreamReader(serverSocket.accept().getInputStream()));    
            	String s = br.readLine();
            	
            	//splitting value of s delimited by :
            	
            	String [] receivedStr = s.split(" "); 	
            	if(receivedStr[1].equals("msg"))
            	{
            		Log.e("Log", "in sequencer");
            		//making port 11108 as sequencer for purpose of ordering
            		if(myPort.equals("11108"))        				 
            		{
            			sequencer(receivedStr[0]);   				 
            		}
            	}
            	
            	
            	if(receivedStr[1].equals("order"))
            	{
            		Log.e("Log", "in msg order");
            		int seq_1 = Integer.valueOf(receivedStr[2]);
            		receivedmap.put(seq_1,receivedStr[0]);
            		
            		while(receivedmap.containsKey(own_counter))
            		{
            			Log.e("Log", "in while");
            			int key = own_counter;
            			String value =receivedmap.get(own_counter);
            			receivedmap.remove(own_counter);
            			//insert message and sequence in database for querying
            			 
            			ContentValues keyValueToInsert = new ContentValues();
            		        	keyValueToInsert.put("key", key);
            		        	keyValueToInsert.put("value",value);
            		        
            		           Uri newUri = getContentResolver().insert(
            		      		    providerUri,    
            		      		    keyValueToInsert
            		      		    );    
            		          own_counter+=1;
            			publishProgress(key+" "+value);
            			
            		}
            	}
               } 
            	
            			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            return null;
        }

        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strReceived + "\t\n");
           
            /*
             * The following code creates a file in the AVD's internal storage and stores a file.
             * 
             * For more information on file I/O on Android, please take a look at
             * http://developer.android.com/training/basics/data-storage/files.html
             */
            
            String filename = "GroupMessengerOutput";
            String string = strReceived + "\n";
            FileOutputStream outputStream;

            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                outputStream.write(string.getBytes());
                outputStream.close();
            } catch (Exception e) {
                Log.e(TAG, "File write failed");
            }

            return;
        }
        
        public void sequencer(String message)
        {
        	 
        	 String seq=""+sequence;
        	 Log.e("Log", "in sequencer function");
        	 new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,message,"order",seq);   //for getting finally ordered message 
        	 sequence++;
        	 Log.e(TAG, "After client call");
        }
    }
    
    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
        	
    
        	Log.e("Log", "in client ");
        	
        	if(msgs[1].contains("order"))
        	{
        		Log.e("order", "client order");
        		String msgToSend = msgs[0]+" "+msgs[1]+" "+ msgs[2]; 
        		try{
         
        			 Socket socket0 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                             Integer.parseInt(REMOTE_PORT0));
        			 Socket socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                             Integer.parseInt(REMOTE_PORT1));
        			 Socket socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                             Integer.parseInt(REMOTE_PORT2));
        			 Socket socket3 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                             Integer.parseInt(REMOTE_PORT3));
        			 Socket socket4 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                             Integer.parseInt(REMOTE_PORT4));
        			
        			PrintWriter pw0 = new PrintWriter(socket0.getOutputStream(),true);
                    pw0.write(msgToSend); 
                    pw0.flush(); 
                    pw0.close();
                    socket0.close();
                    
                    PrintWriter pw1 = new PrintWriter(socket1.getOutputStream(),true);
                    pw1.write(msgToSend); 
                    pw1.flush(); 
                    pw1.close();
                    socket1.close();
                    
                    PrintWriter pw2 = new PrintWriter(socket2.getOutputStream(),true);
                    pw2.write(msgToSend); 
                    pw2.flush(); 
                    pw2.close();
                    socket2.close();
                    
                    PrintWriter pw3 = new PrintWriter(socket3.getOutputStream(),true);
                    pw3.write(msgToSend); 
                    pw3.flush(); 
                    pw3.close();
                    socket3.close();
                    
                    PrintWriter pw4 = new PrintWriter(socket4.getOutputStream(),true);
                    pw4.write(msgToSend); 
                    pw4.flush(); 
                    pw4.close();
                    socket4.close();
                    
        			
                	}catch (UnknownHostException e) {
                        Log.e(TAG, "ClientTask UnknownHostException");
                    } catch (IOException e) {
                        Log.e(TAG, "ClientTask socket IOException");
                	}
        	}
        	else
        	{	
        		
        		Log.e("Log", "client msg");
        		msgs[0]=msgs[0].trim();
        		String msgToSend = msgs[0]+" "+msgs[1]; 
        		 Log.e("Original msg",msgs[0]+" "+msgs[1]);
        	try{
        		 
        	 Socket socket0 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT0));
   			 Socket socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT1));
   			 Socket socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT2));
   			 Socket socket3 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT3));
   			 Socket socket4 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT4));
   			
   			PrintWriter pw0 = new PrintWriter(socket0.getOutputStream(),true);
               pw0.write(msgToSend); 
               pw0.flush(); 
               pw0.close();
               socket0.close();
               
               PrintWriter pw1 = new PrintWriter(socket1.getOutputStream(),true);
               pw1.write(msgToSend); 
               pw1.flush(); 
               pw1.close();
               socket1.close();
               
               PrintWriter pw2 = new PrintWriter(socket2.getOutputStream(),true);
               pw2.write(msgToSend); 
               pw2.flush(); 
               pw2.close();
               socket2.close();
               
               PrintWriter pw3 = new PrintWriter(socket3.getOutputStream(),true);
               pw3.write(msgToSend); 
               pw3.flush(); 
               pw3.close();
               socket3.close();
               
               PrintWriter pw4 = new PrintWriter(socket4.getOutputStream(),true);
               pw4.write(msgToSend); 
               pw4.flush(); 
               pw4.close();
               socket4.close();
               	
        		
        	}catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ClientTask socket IOException");
        	}
          
        }
        	 return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
}


